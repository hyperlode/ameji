Project:	Commentics

Website:	http://www.commentics.org

Version:	v2.5 (9th March 2014)

Description:	Integrates into your website to allow visitors to submit comments

Installation:	(Novice Users) Follow the 'Getting Started' guide at http://www.commentics.org/wiki
		(Expert Users) Follow the installation and integration files in the /docs/ folder

Requirements:	See /docs/requirements.txt

Changelog:	See /docs/changelog.txt

Support:	http://www.commentics.org/forum

Upgrade:	http://www.commentics.org/upgrade.php

License:	GPL v3